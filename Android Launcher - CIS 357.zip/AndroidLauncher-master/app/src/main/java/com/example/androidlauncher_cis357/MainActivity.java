package com.example.androidlauncher_cis357;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MotionEventCompat;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.GridView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<AppObject> installedAppList = new ArrayList<>();
    List<AppObject> homeAppList = new ArrayList<>();
    boolean isBottom = true;
    ViewPager homeViewPager;
    int cellHeight;
    int NUM_ROWS = 5;
    int DRAWER_PEEK = 200;
    GridView drawerGridView;
    BottomSheetBehavior bottomSheetBehavior;
    AppObject appDrag = null;
    ViewPagerAdapter hViewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        initHome();
        initDrawer();

    }

    private void initHome() {
        ArrayList<PagerObject> pagerAppList = new ArrayList<>();
        ArrayList<AppObject> appList = new ArrayList<>();
        for(int i = 0; i < 20; i++){
            appList.add(new AppObject("","",getResources().getDrawable(R.drawable.ic_launcher_foreground)));
        }
        pagerAppList.add(new PagerObject(appList));

        cellHeight = (getDisplayContentHeight() - DRAWER_PEEK) / NUM_ROWS;

        homeViewPager = findViewById(R.id.viewPager);
        hViewPagerAdapter = new ViewPagerAdapter(this, pagerAppList, cellHeight);
        homeViewPager.setAdapter(hViewPagerAdapter);

    }

    private void initDrawer() {
        final View bottomSheet = findViewById(R.id.bottomSheet);
        drawerGridView = findViewById(R.id.drawerGrid);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);

        bottomSheetBehavior.setHideable(false);
        bottomSheetBehavior.setPeekHeight(DRAWER_PEEK);

        //Need a way to hide the drawer completely when not in use. Swipe up opens the drawer.

        installedAppList = getInstalledAppList();
        drawerGridView.setAdapter(new AppAdapter(getApplicationContext(),installedAppList, cellHeight));

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View view, int i) {
                if(appDrag != null){
                    return;
                }
                if(i == BottomSheetBehavior.STATE_COLLAPSED && drawerGridView.getChildAt(0).getY() != 0){
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
                if(i == BottomSheetBehavior.STATE_DRAGGING && drawerGridView.getChildAt(0 ).getY() != 0){
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            }

            @Override
            public void onSlide(@NonNull View view, float v) {

            }
        });
       // homeAppList = getHomeAppList();

    }

    public void itemPress(AppObject app){
        if(appDrag != null){
            app.setPackageName(appDrag.getPackageName());
            app.setName(appDrag.getAppName());
            app.setImage(appDrag.getAppImage());
            appDrag = null;
            hViewPagerAdapter.notifyGridChange();

            return;
        }
        else {
            Intent launchAppIntent = getApplicationContext().getPackageManager().getLaunchIntentForPackage(app.getPackageName());
            if (launchAppIntent != null)
                getApplicationContext().startActivity(launchAppIntent);
        }
    }

    public void itemLongPress(AppObject app){ //drag app on long tap
        collapseDrawer();
        appDrag = app;
    }

    private void collapseDrawer() {
        drawerGridView.setY(0);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
    }


    private List<AppObject> getInstalledAppList() {
        List<AppObject> list = new ArrayList<>();

        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> untreatedAppList = getApplicationContext().getPackageManager().queryIntentActivities(intent, 0); //Gets list of all apps

        for(ResolveInfo untreatedApp : untreatedAppList){
            String appName = untreatedApp.activityInfo.loadLabel(getPackageManager()).toString(); //Get the name of each app
            String appPackageName = untreatedApp.activityInfo.packageName; //Get package name of each app
            Drawable appImage = untreatedApp.activityInfo.loadIcon(getPackageManager()); //Get Image of each app

            AppObject app = new AppObject(appPackageName,appName,appImage); //Pass all to the new app object
            if(!list.contains(app)){
                list.add(app); //Add app to list only if it does not already exist
            }
        }
        return list;
    }

    private int getDisplayContentHeight() {
        final WindowManager windowManager = getWindowManager();
        final Point size = new Point();
        int screenHeight = 0;
        int actionBarHeight = 0;
        int statusBarHeight = 0;
        if(getActionBar()!=null){
            actionBarHeight = getActionBar().getHeight();
        }
        int resourceId = getResources().getIdentifier("status_bar_height","dimension","android");
        if(resourceId > 0){
            statusBarHeight = getResources().getDimensionPixelSize(resourceId);
        }
        int contentTop = (findViewById(android.R.id.content)).getTop();
        windowManager.getDefaultDisplay().getSize(size);
        screenHeight = size.y;
        return screenHeight - contentTop - actionBarHeight - statusBarHeight;
    }

}
